// Demo 18 Js file
$(document).ready(function() {
    'use strict';
});