var loaderbg = document.querySelector(".loader-bg");

window.addEventListener('load', function() {

    loaderbg.classList.add('fondu-out');
    loaderbg.style.display = 'none';
})