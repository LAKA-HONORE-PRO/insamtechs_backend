
<section id="topbar" class="d-flex align-items-left">
  <div class="container-fluid d-flex justify-content-between justify-content-md-between" style="margin-top: 5px">
    <div class="contact-info d-flex align-items-left justify-content-space-between" style="margin-top: 5px">
      {{-- <i class="bi bi-envelope-fill"></i><a href="mailto:contact@example.com" style="margin-top: 8px">serviceestuaires@gmail.com</a>
      &nbsp;
      &nbsp;
      &nbsp; --}}
      <i class="bi bi-phone-fill phone-icon"></i><a href="#" style="margin-top: 8px">696 52 36 72</a> 

    </div>

      <div class="contact-info d-flex align-items-left" style="margin-top: 5px">
      

            @if (LaravelLocalization::getCurrentLocale() == 'en')
              @php
                $localcode = 'fr';
              @endphp
            @else
              @php
                  $localcode = 'en';
              @endphp
            @endif

            <a rel="alternate" hreflang="{{$localcode}}" href="{{ LaravelLocalization::getLocalizedURL($localcode, null, [], true) }}">
              {{$localcode}}
              <i class="bi bi-globe2"></i>

           </a>
  

      </div>


      


  </div>
</section>
