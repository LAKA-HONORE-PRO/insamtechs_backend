<script src="{{URL::asset('public/assets/vendor/purecounter/purecounter_vanilla.js')}}"></script>
<script src="{{URL::asset('public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{URL::asset('public/assets/vendor/glightbox/js/glightbox.min.js')}}"></script>
<script src="{{URL::asset('public/assets/vendor/aos/aos.js')}}"></script>
<script src="{{URL::asset('public/assets/vendor/isotope-layout/isotope.pkgd.min.js')}}"></script>
<script src="{{URL::asset('public/assets/vendor/swiper/swiper-bundle.min.js')}}"></script>
<script src="{{URL::asset('public/assets/vendor/php-email-form/validate.js')}}"></script>
<script src="{{URL::asset('public/dashboard/assets/js/chargement.js')}}"></script>
<script src="{{URL::asset('public/dashboard/assets/js/sweetalert2.min.js')}}"></script>
<script src="{{URL::asset('public/dashboard/assets/js/recherche.js')}}"></script>

<script src="{{URL::asset('public/chosen/docsupport/jquery-3.2.1.min.js')}}" type="text/javascript" charset="utf-8"></script>
<script src="{{URL::asset('public/chosen/chosen.jquery.js')}}" type="text/javascript" charset="utf-8"></script>
<script src="{{URL::asset('public/chosen/docsupport/prism.js')}}" type="text/javascript" charset="utf-8"></script>
<script src="{{URL::asset('public/chosen/docsupport/init.js')}}" type="text/javascript" charset="utf-8"></script>

<script src="{{URL::asset('public/assets/js/main.js')}}"></script>