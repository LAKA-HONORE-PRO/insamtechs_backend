<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estuaire Learning</title>

  
    <link href="{{URL::asset('public/assets/img/admin/logo-estuaire.png')}}" rel="icon">
    <link href="{{URL::asset('public/assets/img/admin/logo-estuaire.png')}}" rel="apple-touch-icon">

    <link rel="stylesheet" href="{{URL::asset('public/dashboard/assets/css/sweetalert2.css')}}">

        {{-- <link rel="stylesheet" href="{{URL::asset('public/chosen/docsupport/style.css')}}"> --}}
    <link rel="stylesheet" href="{{URL::asset('public/chosen/docsupport/prism.css')}}">
    <link rel="stylesheet" href="{{URL::asset('public/chosen/chosen.css')}}">
    <link rel="stylesheet" href="{{URL::asset('public/chosen/chosen.min.css')}}">

    <link href="{{URL::asset('public/assets/vendor/animate.css/animate.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('public/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('public/assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
    <link href="{{URL::asset('public/assets/vendor/boxicons/css/boxicons.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('public/assets/vendor/glightbox/css/glightbox.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('public/assets/vendor/swiper/swiper-bundle.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('public/assets/vendor/aos/aos.css')}}" rel="stylesheet">

    <script src="{{URL::asset('public/assets/js/typed.min.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.min.js"></script>
    
    <link href="{{URL::asset('public/assets/css/style.css')}}" rel="stylesheet">

</head>