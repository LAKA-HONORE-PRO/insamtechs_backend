<section id="hero_other">
  <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

    <ol class="carousel-indicators_other" id="hero-carousel-indicators_other"></ol>

    <div class="carousel-inner_other" role="listbox">

      <!-- Slide 1 -->
      <div class="carousel-item_other active">
        <div class="carousel-container_other">
          <div class="container_other">
            <h2 class="animate__animated animate__fadeInDown"><span> @lang('message.fascicule') </span></h2>
            <p class="animate__animated animate__fadeInDown">@lang('message.home') / {{ ucfirst($domaine->intitule) }} </p> 

            <!-- <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Passez à l'action</a> -->
          </div>
        </div>
      </div>



    </div>


  </div>
</section><!-- End Hero -->






<main id="main">

  <!-- ======= Portfolio Details Section ======= -->
  <section id="portfolio-details" class="portfolio-details">
    <div class="container-fluid">

      <div class="row gy-4">

        <div class="col-lg-9">
     


          <section id="portfolio" class="section-bg ">
              <div class="container">
        

                <div class="section-title" >
                  <h2>@lang('message.fascicule')</h2>
                </div>
        
        
              <div class="row portfolio-container">

                @foreach ($categories as $categorie)

                <div class="col-lg-4 col-md-6 portfolio-item filter-app animate__animated animate__fadeInUp">
                  <div class="portfolio-wrap">
                    <figure>
                      <img src="{{URL::asset('public/assets/img/admin/dossier1.jpg')}}" class="img-fluid" alt="">
                    </figure>
        
                    <div class="portfolio-info">
                      <h4><a href="{{route('detailsfascicule', $categorie->slug)}}" class="btn btn-primary voir-plus"> Afficher les fascicules </a></h4>
                      <p>{{ucfirst($categorie->intitule)}}</p>
                    </div>
                  </div>
                </div>

                @endforeach
                  

      
  
                
        
      
              </div>
        
              {{$categories->links('pagination::bootstrap-4')}}
    
      
              </div>
            </section><!-- End Portfolio Section -->
      

          
        </div>

        <div class="col-lg-3">
          <div class="portfolio-info">
            <h3>Séries récentes</h3>
            <ul>

                @forelse ($domaines as $dom)
                <li><strong><a href="{{route('detailsseries', $dom->slug)}}">{{strtoupper($dom->intitule)}}</a></strong>
                  
                @empty
                <div class="col-lg-12 d-flex align-items-center justify-content-center">
                  <h4 style="color: rgb(88, 16, 197); font-size:14px">@lang('message.aucun_element') !</h4>
                </div>
                @endforelse
       
            </ul>
          </div>
          

 
        </div>

      </div>

    </div>
  </section><!-- End Portfolio Details Section -->

</main>
