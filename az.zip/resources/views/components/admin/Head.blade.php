<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Insam Technologie</title>
  <meta content="" name="description">
  <meta content="" name="keywords">



  <link href="{{URL::asset('assets/img/admin/logo-estuaire.png')}}" rel="icon">
  <link href="{{URL::asset('assets/img/admin/logo-estuaire.png')}}" rel="apple-touch-icon">


  <link rel="stylesheet" href="{{URL::asset('dashboard/assets/css/sweetalert2.css')}}">


  {{-- <link rel="stylesheet" href="{{URL::asset('chosen/docsupport/style.css')}}"> --}}
  <link rel="stylesheet" href="{{URL::asset('chosen/docsupport/prism.css')}}">
  <link rel="stylesheet" href="{{URL::asset('chosen/chosen.css')}}">
  <link rel="stylesheet" href="{{URL::asset('chosen/chosen.min.css')}}">

  <!-- Vendor CSS Files -->
  <link href="{{URL::asset('dashboard/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{URL::asset('dashboard/assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
  <link href="{{URL::asset('dashboard/assets/vendor/boxicons/css/boxicons.min.css')}}" rel="stylesheet">
  <link href="{{URL::asset('dashboard/assets/vendor/quill/quill.snow.css')}}" rel="stylesheet">
  <link href="{{URL::asset('dashboard/assets/vendor/quill/quill.bubble.css')}}" rel="stylesheet">
  <link href="{{URL::asset('dashboard/assets/vendor/remixicon/remixicon.css')}}" rel="stylesheet">
  <link href="{{URL::asset('dashboard/assets/vendor/simple-datatables/style.css')}}" rel="stylesheet">





<link href="{{URL::asset('dashboard/assets/css/style.css')}}" rel="stylesheet">

<!-- <script type="text/javascript" src="{{URL::asset('assets/jss/chosen/chosen.jquery.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/jss/chosen/chosen.jquery.min.js')}}"></script> -->
<script type="text/javascript" src="{{URL::asset('assets/jss/jquery.min.js')}}"></script>


  
</head>