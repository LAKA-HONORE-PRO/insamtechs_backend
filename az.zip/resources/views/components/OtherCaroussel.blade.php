<section id="hero_other">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <ol class="carousel-indicators_other" id="hero-carousel-indicators_other"></ol>

      <div class="carousel-inner_other" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item_other active">
          <div class="carousel-container_other">
            <div class="container_other">
              <h2 class="animate__animated animate__fadeInDown"><span>{{$key}}</span></h2>
              <p class="animate__animated animate__fadeInDown">Accueil / {{$key}}</p> 

              <!-- <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Passez à l'action</a> -->
            </div>
          </div>
        </div>



      </div>


    </div>
</section><!-- End Hero -->
