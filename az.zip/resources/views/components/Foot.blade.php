<script src="{{URL::asset('assets/vendor/purecounter/purecounter_vanilla.js')}}"></script>
<script src="{{URL::asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{URL::asset('assets/vendor/glightbox/js/glightbox.min.js')}}"></script>
<script src="{{URL::asset('assets/vendor/aos/aos.js')}}"></script>
<script src="{{URL::asset('assets/vendor/isotope-layout/isotope.pkgd.min.js')}}"></script>
<script src="{{URL::asset('assets/vendor/swiper/swiper-bundle.min.js')}}"></script>
<script src="{{URL::asset('assets/vendor/php-email-form/validate.js')}}"></script>
<script src="{{URL::asset('dashboard/assets/js/chargement.js')}}"></script>
<script src="{{URL::asset('dashboard/assets/js/sweetalert2.min.js')}}"></script>
<script src="{{URL::asset('dashboard/assets/js/recherche.js')}}"></script>

<script src="{{URL::asset('chosen/docsupport/jquery-3.2.1.min.js')}}" type="text/javascript" charset="utf-8"></script>
<script src="{{URL::asset('chosen/chosen.jquery.js')}}" type="text/javascript" charset="utf-8"></script>
<script src="{{URL::asset('chosen/docsupport/prism.js')}}" type="text/javascript" charset="utf-8"></script>
<script src="{{URL::asset('chosen/docsupport/init.js')}}" type="text/javascript" charset="utf-8"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.min.js"></script>
<script src="{{URL::asset('assets/js/main.js')}}"></script>