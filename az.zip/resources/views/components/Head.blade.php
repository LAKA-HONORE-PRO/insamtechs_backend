<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insam Technologie</title>

  
    <link href="{{URL::asset('assets/img/admin/logo_insam.png')}}" rel="icon">
    <link href="{{URL::asset('assets/img/admin/logo_insam.png')}}" rel="apple-touch-icon">

    <link rel="stylesheet" href="{{URL::asset('dashboard/assets/css/sweetalert2.css')}}">

        {{-- <link rel="stylesheet" href="{{URL::asset('chosen/docsupport/style.css')}}"> --}}
    <link rel="stylesheet" href="{{URL::asset('chosen/docsupport/prism.css')}}">
    <link rel="stylesheet" href="{{URL::asset('chosen/chosen.css')}}">
    <link rel="stylesheet" href="{{URL::asset('chosen/chosen.min.css')}}">

    <link href="{{URL::asset('assets/vendor/animate.css/animate.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
    <link href="{{URL::asset('assets/vendor/boxicons/css/boxicons.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('assets/vendor/glightbox/css/glightbox.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('assets/vendor/swiper/swiper-bundle.min.css')}}" rel="stylesheet">
    <link href="{{URL::asset('assets/vendor/aos/aos.css')}}" rel="stylesheet">

    <script src="{{URL::asset('assets/js/typed.min.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.min.js"></script>
    
    <link href="{{URL::asset('assets/css/style.css')}}" rel="stylesheet">

</head>